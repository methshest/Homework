package ru.inordic.lesson1;

import java.util.Scanner;

public class Calc {
    public static void main(String[] args) {
        int itog = 0;
        System.out.println("выберите режим работы:\n0-целые числа\n1-дробные\n1-boolean");
        Scanner st = new Scanner(System.in);
        int start = st.nextInt();
        // Часть с целыми числами - арифметические,логические и побитовые операции #int
        if (start == 0) {
            System.out.println("Введите первое число:");
            Scanner scanner = new Scanner(System.in);
            int a = scanner.nextInt();
            System.out.println("Введите второе число:");
            Scanner scan = new Scanner(System.in);
            int b = scan.nextInt();
            System.out.println("Введите код операции:\n0-сумма\n1-разность\n2-произведение\n3-деление\n4-конъюкция\n5-дизъюнкция\n6-сложение по модулю(исключающее или)" +
                    "\n7-побитовый NOT\n8-побитовый AND\n9-побитовый OR\n10-побитовый notOR\n11-сдвиг вправо\n12-сдвиг влево\n13-сдвиг вправо с нулями");
            Scanner s = new Scanner(System.in);
            int sum = s.nextInt();
            if (sum == 0) {
                itog = a + b;
                System.out.println("Результат:" + itog);
            }
            if (sum == 1) {
                itog = a - b;
                System.out.println("Результат:" + itog);
            }
            if (sum == 2) {
                itog = a * b;
                System.out.println("Результат:" + itog);
            }
            if (sum == 3 && b != 0) {
                itog = a / b;
                System.out.println("Результат:" + itog);

            } else if (sum == 3 && b == 0) {
                System.out.println("На ноль не могу делить");
            }
            if (sum < 0 || sum > 13) {
                System.out.println("Нет такой операции");
            }
            if (sum == 4) {
                System.out.println("Введите число для сравнения");
                Scanner c = new Scanner(System.in);
                int com = c.nextInt();
                if ((a == com) && (b == com)) {
                    System.out.println("True");
                } else
                    System.out.println("False");
            }
            if (sum == 5) {
                System.out.println("Введите число для сравнения");
                Scanner c = new Scanner(System.in);
                int com = c.nextInt();
                if ((a == com) || (b == com)) {
                    System.out.println("True");
                } else
                    System.out.println("False");
            }
            if (sum == 6) {
                System.out.println("Введите число для сравнения");
                Scanner c = new Scanner(System.in);
                int com = c.nextInt();
                if ((a == com) ^ (b == com)) {
                    System.out.println("True");
                } else
                    System.out.println("False");
            }
            if (sum == 7) {
                System.out.println("Результат:a=" + ~a);
                System.out.println("Результат:b=" + ~b);
            }
            if (sum == 8) {
                System.out.println("Результат:" + (a & b));
            }
            if (sum == 9) {
                System.out.println("Результат:" + (a | b));
            }
            if (sum == 10) {
                System.out.println("Результат:" + (a ^ b));
            }
            if (sum == 11) {
                System.out.println("Результат:" + (a >> b));
            }
            if (sum == 12) {
                System.out.println("Результат:" + (a << b));
            }
            if (sum == 13) {
                System.out.println("Результат:" + (a >>> b));
            }
              //Часть с дробными числами #float
        }
        if (start == 1) {
            float resf;
            System.out.println("Введите первое число:");
            Scanner scf1 = new Scanner(System.in);
            float a = scf1.nextFloat();
            System.out.println("Введите второе число:");
            Scanner scf2 = new Scanner(System.in);
            float b = scf2.nextFloat();
            System.out.println("Введите код операции:\n0-сумма\n1-разность\n2-произведение\n3-деление");
            Scanner s = new Scanner(System.in);
            int sum = s.nextInt();
            if (sum == 0) {
                resf = a + b;
                System.out.println("Результат:" + resf);
            }
            if (sum == 1) {
                resf = a - b;
                System.out.println("Результат:" + resf);
            }
            if (sum == 2) {
                resf = a * b;
                System.out.println("Результат:" + resf);
            }
            if (sum == 3 && Math.signum(b) != 0) {
                resf = a / b;
                System.out.println("Результат:" + resf);

            } else if (sum == 3 && Math.signum(b) == 0) {
                System.out.println("На ноль не могу делить");
            }
            if (sum < 0 || sum > 4) {
                System.out.println("Нет такой операции");
            }

        }
        if (start == 2){
            System.out.println("Введите первое значение(доступно true/false):");
            Scanner scanner = new Scanner(System.in);
            boolean a = scanner.nextBoolean();
            System.out.println("Введите второе значение(доступно true/false):");
            Scanner scan = new Scanner(System.in);
            boolean b = scan.nextBoolean();
            System.out.println("Введите код операции:0-Отрицание\n1-конъюкция\n5-дизъюнкция\n6-сложение по модулю(исключающее или)");
        }
    }
    }





