package ru.nordic.lesson5.rec;

public class   Product {
   private double  cost;
   private int shelfNumber;
    private String name;
    private int idCode;
    private  final static int shelfCount=20;



//    public Product(double cost,int shelfNumber,String name,int idCode){
//        this.cost=cost;
//        this.shelfNumber=shelfNumber;
//        this.name=name;
//        this.idCode=idCode;
//    }



    public void setShelfNumber(int shelfNumber){
        if (shelfNumber<=shelfCount && shelfNumber>0) {
            this.shelfNumber = shelfNumber;
        }else {
            System.out.println("Что-то по полочкам не сходится,перепроверь");
            throw new NullPointerException();
        }
    }
    public int getShelfNumber(int shelfNumber){
        return shelfNumber;
    }
    public void setCost(double cost){
        this.cost=cost;
    }
    public double getCost(double cost){
        return cost;
    }




    public String getName() {
        return name;
    }

    public int getIdCode() {
        return idCode;
    }
    public void setName(String name){
        this.name=name;
    }
    public void setIdCode(int idCode){
        this.idCode=idCode;
    }
    public String getinfo(){
        StringBuilder sb=new StringBuilder();
        sb.append("Cost: "+cost);
        sb.append("\nShelfNumber: "+ shelfNumber);
        sb.append("\nName: "+name);
        sb.append("\nID: "+idCode);
        return  sb.toString();
    }
}
