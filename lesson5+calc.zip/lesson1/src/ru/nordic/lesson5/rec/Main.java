package ru.nordic.lesson5.rec;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Product p = new Product();
        p.setCost(14.3);
        p.setShelfNumber(19);
        p.setIdCode(133333);
        p.setName("Derevo");
        System.out.println(p.getinfo());


    }
}
//    public  int Recur(int cur,int step,int maxStep){
//        int result=1;
//        if (step<maxStep){
//            result=cur++;
//            return result;
//        }
//        return result=cur+step;
//    }
//    private static int recurs(int curr, int step, int maxVal) {
//        int result=1;
//        if (curr < maxVal) {
//            return recurs(curr + step, step, maxVal);
//        }
//        return curr;
//    }
//
//    public static int recur( int step,int n) {
//        int result = 0;
//        if (step<n) {
//        step++;
//        result=step++;
//        return result;
//        }
//        result = n + recur(step- 1,n-1);
//        return result;
//    }
//}
